function dir_list = DirList(filename)
allf_dir = dir(fullfile(filename));
allf_len = length(allf_dir);

dir_num = 0;
dir_list = {};
for l = 1 : allf_len
    if (isfolder([filename, '/', allf_dir(l).name]) == 1) && (strcmp(allf_dir(l).name, '.') == 0) && (strcmp(allf_dir(l).name, '..') == 0)
        dir_num = dir_num + 1;
        dir_list{dir_num} = allf_dir(l).name;
    end
end
end