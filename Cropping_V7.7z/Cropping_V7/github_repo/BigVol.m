function [vol, nii_info] = BigVol(nii_fold)
%nii_fold = '00000738_00004032_R_nii';
slice_list = dir(fullfile(nii_fold, '*.nii'));
image_size = niftiinfo([nii_fold, '/', slice_list(1).name]).ImageSize;
vol = int16(zeros(image_size(1), image_size(2), length(slice_list)));
vol_qoffset_z = 0;
for i = 1 : length(slice_list)
    nii_vol = niftiread([nii_fold, '/', slice_list(i).name]);
    nii_info = niftiinfo([nii_fold, '/', slice_list(i).name]);
    vol(:, :, i) = nii_vol;
    vol_qoffset_z = vol_qoffset_z + nii_info.raw.qoffset_z;
end
vol_qoffset_z = vol_qoffset_z / length(slice_list);

nii_info.ImageSize = [image_size(1), image_size(2), length(slice_list)];
pixel_dim = nii_info.PixelDimensions;
pixel_dim = pixel_dim(2);
nii_info.PixelDimensions = [pixel_dim, pixel_dim, pixel_dim];
nii_info.SpatialDimension = 3;
nii_info.raw.dim(1) = 3;
nii_info.raw.dim(4) = length(slice_list);
nii_info.raw.pixdim(6) = 1;
nii_info.raw.pixdim(7) = 1;
nii_info.raw.qoffset_z = vol_qoffset_z;
nii_info.raw.srow_z(4) = vol_qoffset_z;
end

%niftiwrite(vol, 'big_vol.nii', nii_info);