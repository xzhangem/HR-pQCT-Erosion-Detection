function FillDcm2Nii(dcm_fold, nii_fold)

addpath('./github_repo');
%dcm_fold = '00000738_00004032_R';

temp_fold = 'NIIfile';
if exist(temp_fold, 'dir')
    rmdir(temp_fold, 's');
end
mkdir(temp_fold);
%nii_fold = '00000738_00004032_R_nii';
if ~exist(nii_fold, 'dir')
    mkdir(nii_fold);
end
slice_list = dir(fullfile(dcm_fold, '*.dcm'));

for i = 1 : length(slice_list)
    dcm_name = [dcm_fold, '/', slice_list(i).name];
    prefix = strsplit(slice_list(i).name, '.');
    prefix = prefix{1};
    save_name = [temp_fold, '/', prefix, '.nii'];
    dicm2nii(dcm_name, temp_fold, 0);
    cur_nii = dir(fullfile(temp_fold, '*.nii'));
    movefile([temp_fold, '/',cur_nii(1).name], save_name);
    movefile(save_name, nii_fold);
end
rmdir(temp_fold, 's');
end