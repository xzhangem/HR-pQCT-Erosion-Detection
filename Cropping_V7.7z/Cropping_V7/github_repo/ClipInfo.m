function c_info = ClipInfo(info, cx, cy)
c_info = info;
c_info.ImageSize(1) = cx;
c_info.ImageSize(2) = cy;

c_info.raw.dim(2) = cx;
c_info.raw.dim(3) = cy;
end