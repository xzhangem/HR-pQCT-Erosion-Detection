function diff_vec = CenterDiff(vol)
[con_lab, num] = bwlabel(vol, 4);
[vx, vy] = size(con_lab);
[xx, yy] = ndgrid(1 : vx, 1 : vy);
center_pos = zeros(num, 2);
for l = 1 : num
    l_region = single(con_lab == l);
    center_x = sum(sum(xx .* l_region)) / sum(l_region(:));
    center_y = sum(sum(yy .* l_region)) / sum(l_region(:));
    
    center_pos(l, 1) = center_x;
    center_pos(l, 2) = center_y;
end

cent_x = center_pos(:, 1);
[~, centx_indx] = sort(cent_x, 'ascend');
ascd_cent_pos = center_pos(centx_indx, :);

diff_vec = zeros(num - 1, 1);
for i = 1 : (num - 1)
    diff_vec(i,1) = sqrt((ascd_cent_pos(i+1, 1) - ascd_cent_pos(i, 1))^2 + (ascd_cent_pos(i+1, 2) - ascd_cent_pos(i, 2))^2);
end
end